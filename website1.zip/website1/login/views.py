from django.shortcuts import render
import mysql.connector as sql
em=''
pwd=''

# Create your views here.
def loginaction(request):
    global em,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Deepaksai@2003",database='hotel1')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="email":
                em=value
            if key=="password":
                pwd=value

        c="select * from users where email='{}' and password='{}'".format(em,pwd)

        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'error.html')
        else:
            return render(request,'home.html')
        

    return render(request,'login_page.html')
fn=''
ln=''
em=''
dob=''
gen=''
pd=''
cn=''
cvc=''
def payment(request):
    global fn, ln, em, dob, gen, pd, cn, cvc
    if request.method == "POST":
        m = sql.connect(host="localhost", user="root", passwd="Deepaksai@2003", database='hotel1')
        cursor = m.cursor()
        d = request.POST
        for key, value in d.items():
            if key == "data_1":
                fn = value
            if key == "data_2":
                ln = value
            if key == "data_3":
                em = value
            if key == "data_4":
                dob = value
            if key == "data_4":
                dob = value
            if key == "data_4":
                dob = value
            if key == "gendar":
                gen = value
            if key == "pay":
                pd = value
            if key == "cardnumber":
                cn = value
            if key == "CVC":
                cvc = value

        c = "insert into pay Values('{}','{}','{}','{}','{}','{}','{}')".format(fn, ln, em, dob, gen, pd, cn, cvc)
        cursor.execute(c)
        m.commit()
    return render(request, 'Payment.html')

fn=''
ln=''
em=''
co=''
fd=''
def feedback(request):
    global fn, ln, em, co, fd
    if request.method == "POST":
        m = sql.connect(host="localhost", user="root", passwd="Deepaksai@2003", database='hotel1')
        cursor = m.cursor()
        d = request.POST
        for key, value in d.items():
            if key == "firstname":
                fn = value
            if key == "lastname":
                ln = value
            if key == "mailid":
                em = value
            if key == "country":
                co = value
            if key == "subject":
                fd = value

        c = "insert into feedback Values('{}','{}','{}','{}','{}')".format(fn, ln, em, co, fd)
        cursor.execute(c)
        t = tuple(cursor.fetchall())
        if t == ():
            return render(request, 'success3.html')
        else:
            return render(request, 'success3.html')
        m.commit()


    return render(request, 'feebackform.html')
