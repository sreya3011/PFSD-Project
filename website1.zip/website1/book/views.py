from django.shortcuts import render
import mysql.connector as sql

# Create your views here.
fn=''
ln=''
ph=''
em=''
Ad=''
De=''
Na=''
Nc=''
Qu=''

def book(request):
    global fn,ln,ph,em,Ad,De,Ns,Nc,Qu
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Deepaksai@2003",database='hotel1')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="data_2":
                fn=value
            if key=="data_3":
                ln=value
            if key=="data_4":
                ph=value
            if key=="data_5":
                em=value
            if key=="data_6":
                Ad=value
            if key=="data_7":
                De=value
            if key=="data_8":
                Na=value
            if key=="data_9":
                Nc=value
            if key=="data_10":
                Qu=value

        c = "insert into book Values('{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(fn,ln,ph,em,Ad,De,Na,Nc,Qu)
        cursor.execute(c)
        t = tuple(cursor.fetchall())
        if t == ():
            return render(request, 'success2.html')
        else:
            return render(request, 'success2.html')

        m.commit()

    return render(request, 'booking.html')

def room(request):
    return render(request, 'rooms.html')
def success2(request):
    return render(request, 'success2.html')
def contactus(request):
    return render(request, 'contactus.html')
def aboutus(request):
    return render(request, 'aboutus.html')
def zebra(request):
    return render(request, 'phonepay.html')