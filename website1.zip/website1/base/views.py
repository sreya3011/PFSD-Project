from django.shortcuts import render

# Create your views here.
def deepak(request):
	return render(request,'base/deepak.html')